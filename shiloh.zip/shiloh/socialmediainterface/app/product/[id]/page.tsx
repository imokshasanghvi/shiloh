"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { Heart, Minus, Plus, Share2, ShoppingBag, Star, Truck } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"
import ProductReviews from "@/components/product-reviews"
import RelatedProducts from "@/components/related-products"

// Mock product data
const products = [
  {
    id: "1",
    name: "Classic Oxford Shirt",
    price: 120000,
    description:
      "A timeless classic, our Oxford shirt is crafted from premium cotton for exceptional comfort and durability. The versatile design features a button-down collar and a regular fit that's perfect for both casual and formal occasions.",
    features: [
      "100% premium cotton",
      "Button-down collar",
      "Regular fit",
      "Machine washable",
      "Available in multiple colors",
    ],
    images: [
      "/placeholder.svg?height=600&width=600&text=Front",
      "/placeholder.svg?height=600&width=600&text=Back",
      "/placeholder.svg?height=600&width=600&text=Side",
      "/placeholder.svg?height=600&width=600&text=Detail",
      "/placeholder.svg?height=600&width=600&text=Collar",
      "/placeholder.svg?height=600&width=600&text=Fabric",
    ],
    colors: ["White", "Blue", "Black", "Gray"],
    sizes: ["XS", "S", "M", "L", "XL", "XXL"],
    category: "men",
    subcategory: "shirts",
    rating: 4.5,
    reviewCount: 127,
    inStock: true,
    similarProducts: [
      {
        id: "4",
        name: "Slim Fit Dress Shirt",
        price: 135000,
        image: "/placeholder.svg?height=400&width=300&text=Similar1",
        category: "men",
      },
      {
        id: "7",
        name: "Striped Button-Down",
        price: 110000,
        image: "/placeholder.svg?height=400&width=300&text=Similar2",
        category: "men",
      },
      {
        id: "10",
        name: "Linen Summer Shirt",
        price: 95000,
        image: "/placeholder.svg?height=400&width=300&text=Similar3",
        category: "men",
      },
      {
        id: "13",
        name: "Casual Chambray Shirt",
        price: 125000,
        image: "/placeholder.svg?height=400&width=300&text=Similar4",
        category: "men",
      },
    ],
  },
]

export default function ProductPage({ params }: { params: { id: string } }) {
  const product = products.find((p) => p.id === params.id) || products[0]
  const [mainImage, setMainImage] = useState(product.images[0])
  const [quantity, setQuantity] = useState(1)

  const increaseQuantity = () => {
    setQuantity((prev) => prev + 1)
  }

  const decreaseQuantity = () => {
    if (quantity > 1) {
      setQuantity((prev) => prev - 1)
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col lg:flex-row gap-8">
        {/* Product Images */}
        <div className="lg:w-1/2">
          <div className="mb-4">
            <div className="relative h-[500px] rounded-lg overflow-hidden">
              <Image
                src={mainImage || "/placeholder.svg"}
                alt={`${product.name} - Main Image`}
                fill
                className="object-cover"
              />
            </div>
          </div>
          <div className="grid grid-cols-6 gap-2">
            {product.images.map((image, index) => (
              <div
                key={index}
                className={`relative h-20 rounded-md overflow-hidden cursor-pointer border-2 ${image === mainImage ? "border-shiloh-blue" : "border-transparent"}`}
                onClick={() => setMainImage(image)}
              >
                <Image
                  src={image || "/placeholder.svg"}
                  alt={`${product.name} - Thumbnail ${index + 1}`}
                  fill
                  className="object-cover"
                />
              </div>
            ))}
          </div>
        </div>

        {/* Product Details */}
        <div className="lg:w-1/2">
          <div className="flex flex-col gap-4">
            <div>
              <div className="flex items-center gap-2 text-sm">
                <Link href={`/category/${product.category}`} className="text-black hover:text-shiloh-blue">
                  {product.category.charAt(0).toUpperCase() + product.category.slice(1)}
                </Link>
                <span className="text-black">/</span>
                <Link
                  href={`/category/${product.category}?subcategory=${product.subcategory}`}
                  className="text-black hover:text-shiloh-blue capitalize"
                >
                  {product.subcategory}
                </Link>
              </div>
              <h1 className="text-3xl font-bold mt-2">{product.name}</h1>
            </div>

            <div className="flex items-center gap-2">
              <div className="flex">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`h-5 w-5 ${
                      i < Math.floor(product.rating)
                        ? "text-yellow-400 fill-yellow-400"
                        : i < product.rating
                          ? "text-yellow-400 fill-yellow-400 opacity-50"
                          : "text-black"
                    }`}
                  />
                ))}
              </div>
              <span className="text-sm text-black">
                {product.rating} ({product.reviewCount} reviews)
              </span>
            </div>

            <div className="text-2xl font-bold">TSh {product.price.toLocaleString()}</div>

            <p className="text-black">{product.description}</p>

            <Separator />

            <div className="space-y-4">
              <div>
                <h3 className="font-medium mb-2">Color</h3>
                <Select defaultValue={product.colors[0]}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Select color" />
                  </SelectTrigger>
                  <SelectContent>
                    {product.colors.map((color) => (
                      <SelectItem key={color} value={color}>
                        {color}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <h3 className="font-medium mb-2">Size</h3>
                <Select defaultValue={product.sizes[2]}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Select size" />
                  </SelectTrigger>
                  <SelectContent>
                    {product.sizes.map((size) => (
                      <SelectItem key={size} value={size}>
                        {size}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Link href="/size-guide" className="text-sm text-black underline mt-1 inline-block">
                  Size Guide
                </Link>
              </div>

              <div>
                <h3 className="font-medium mb-2">Quantity</h3>
                <div className="flex items-center border rounded-md w-32">
                  <Button variant="ghost" size="icon" className="rounded-none" onClick={decreaseQuantity}>
                    <Minus className="h-4 w-4" />
                  </Button>
                  <div className="flex-1 text-center">{quantity}</div>
                  <Button variant="ghost" size="icon" className="rounded-none" onClick={increaseQuantity}>
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 mt-4">
              <Button className="flex-1 gap-2 bg-shiloh-blue text-white hover:bg-shiloh-blue/90">
                <ShoppingBag className="h-5 w-5" />
                Add to Cart
              </Button>
              <Button variant="outline" size="icon">
                <Heart className="h-5 w-5" />
              </Button>
              <Button variant="outline" size="icon">
                <Share2 className="h-5 w-5" />
              </Button>
            </div>

            <div className="bg-shiloh-light p-4 rounded-lg flex items-start gap-3 mt-4">
              <Truck className="h-5 w-5 text-shiloh-blue mt-0.5" />
              <div>
                <p className="font-medium">Free Shipping</p>
                <p className="text-sm text-black">Free standard shipping on orders over TSh 200,000</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-16">
        <Tabs defaultValue="description">
          <TabsList className="w-full justify-start border-b rounded-none">
            <TabsTrigger value="description">Description</TabsTrigger>
            <TabsTrigger value="features">Features</TabsTrigger>
            <TabsTrigger value="reviews">Reviews</TabsTrigger>
          </TabsList>
          <TabsContent value="description" className="py-6">
            <div className="prose max-w-none">
              <p className="text-black">{product.description}</p>
              <p className="text-black">
                Our Classic Oxford Shirt is a wardrobe essential that combines timeless style with exceptional comfort.
                Crafted from premium 100% cotton, this shirt offers a soft feel and excellent breathability, making it
                perfect for all-day wear. The button-down collar provides a clean, polished look that transitions
                seamlessly from casual to formal settings.
              </p>
              <p className="text-black">
                The regular fit offers a comfortable silhouette that's neither too slim nor too relaxed, complementing a
                variety of body types. With reinforced stitching at stress points, this shirt is built to last through
                countless wears and washes without losing its shape or color.
              </p>
              <p className="text-black">
                Available in a range of versatile colors, the Classic Oxford Shirt pairs effortlessly with jeans for a
                casual weekend look or with dress pants for more formal occasions. The buttoned cuffs can be rolled up
                for a more relaxed style or kept buttoned for a crisp, professional appearance.
              </p>
            </div>
          </TabsContent>
          <TabsContent value="features" className="py-6">
            <ul className="list-disc pl-5 space-y-2">
              {product.features.map((feature, index) => (
                <li key={index} className="text-black">
                  {feature}
                </li>
              ))}
            </ul>
          </TabsContent>
          <TabsContent value="reviews" className="py-6">
            <ProductReviews productId={product.id} rating={product.rating} reviewCount={product.reviewCount} />
          </TabsContent>
        </Tabs>
      </div>

      {/* Similar Products Section */}
      <div className="mt-16">
        <h2 className="text-2xl font-bold mb-8">Similar Products</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {product.similarProducts.map((similarProduct) => (
            <div key={similarProduct.id} className="group relative">
              <div className="aspect-h-1 aspect-w-1 w-full overflow-hidden rounded-md bg-white group-hover:opacity-75">
                <Image
                  src={similarProduct.image || "/placeholder.svg"}
                  alt={similarProduct.name}
                  width={300}
                  height={400}
                  className="h-full w-full object-cover object-center"
                />
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className="flex gap-2">
                    <Button size="icon" className="rounded-full bg-white text-black hover:bg-white/90">
                      <ShoppingBag className="h-5 w-5" />
                    </Button>
                    <Button size="icon" className="rounded-full bg-white text-black hover:bg-white/90">
                      <Heart className="h-5 w-5" />
                    </Button>
                  </div>
                </div>
              </div>
              <div className="mt-4 flex justify-between">
                <div>
                  <h3 className="text-sm font-medium text-black">
                    <Link href={`/product/${similarProduct.id}`}>
                      <span aria-hidden="true" className="absolute inset-0" />
                      {similarProduct.name}
                    </Link>
                  </h3>
                  <p className="mt-1 text-sm text-black">{similarProduct.category}</p>
                </div>
                <p className="text-sm font-medium text-black">TSh {similarProduct.price.toLocaleString()}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="mt-16">
        <h2 className="text-2xl font-bold mb-8">You May Also Like</h2>
        <RelatedProducts category={product.category} currentProductId={product.id} />
      </div>
    </div>
  )
}

