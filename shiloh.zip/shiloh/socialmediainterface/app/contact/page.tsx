"use client"

import type React from "react"

import { useState } from "react"
import { Mail, MapPin, Phone } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { toast } from "@/hooks/use-toast"

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    toast({
      title: "Message Sent",
      description: "We've received your message and will get back to you soon.",
    })
    setFormData({
      name: "",
      email: "",
      subject: "",
      message: "",
    })
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold mb-4">Contact Us</h1>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Have questions, feedback, or need assistance? We're here to help! Reach out to our team using any of the
            methods below.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-12">
          <div className="bg-white p-6 rounded-lg shadow-sm text-center">
            <div className="mx-auto w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
              <Phone className="h-6 w-6 text-primary" />
            </div>
            <h3 className="font-semibold mb-2">Phone</h3>
            <p className="text-gray-600">+1 (555) 123-4567</p>
            <p className="text-gray-600">Mon-Fri, 9am-6pm EST</p>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-sm text-center">
            <div className="mx-auto w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
              <Mail className="h-6 w-6 text-primary" />
            </div>
            <h3 className="font-semibold mb-2">Email</h3>
            <p className="text-gray-600">support@stylehub.com</p>
            <p className="text-gray-600">We respond within 24 hours</p>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-sm text-center">
            <div className="mx-auto w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
              <MapPin className="h-6 w-6 text-primary" />
            </div>
            <h3 className="font-semibold mb-2">Location</h3>
            <p className="text-gray-600">123 Fashion Street</p>
            <p className="text-gray-600">New York, NY 10001</p>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <h2 className="text-xl font-semibold mb-6">Send Us a Message</h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label htmlFor="name" className="block text-sm font-medium mb-2">
                  Your Name
                </label>
                <Input id="name" name="name" value={formData.name} onChange={handleChange} required />
              </div>

              <div>
                <label htmlFor="email" className="block text-sm font-medium mb-2">
                  Email Address
                </label>
                <Input id="email" name="email" type="email" value={formData.email} onChange={handleChange} required />
              </div>

              <div>
                <label htmlFor="subject" className="block text-sm font-medium mb-2">
                  Subject
                </label>
                <Input id="subject" name="subject" value={formData.subject} onChange={handleChange} required />
              </div>

              <div>
                <label htmlFor="message" className="block text-sm font-medium mb-2">
                  Message
                </label>
                <Textarea
                  id="message"
                  name="message"
                  rows={5}
                  value={formData.message}
                  onChange={handleChange}
                  required
                />
              </div>

              <Button type="submit" className="w-full">
                Send Message
              </Button>
            </form>
          </div>

          <div className="bg-black text-white p-6 rounded-lg">
            <h2 className="text-xl font-semibold mb-6">Customer Support</h2>
            <div className="space-y-6">
              <div>
                <h3 className="font-medium mb-2">Frequently Asked Questions</h3>
                <p className="text-gray-300 mb-2">
                  Find quick answers to common questions in our comprehensive FAQ section.
                </p>
                <Button variant="outline" className="text-white border-white hover:bg-white/10" asChild>
                  <a href="/faq">View FAQs</a>
                </Button>
              </div>

              <div>
                <h3 className="font-medium mb-2">Shipping & Returns</h3>
                <p className="text-gray-300 mb-2">
                  Learn about our shipping policies, delivery times, and hassle-free return process.
                </p>
                <Button variant="outline" className="text-white border-white hover:bg-white/10" asChild>
                  <a href="/shipping">Shipping Info</a>
                </Button>
              </div>

              <div>
                <h3 className="font-medium mb-2">Feedback & Complaints</h3>
                <p className="text-gray-300 mb-2">
                  We value your feedback and are committed to resolving any issues you may encounter.
                </p>
                <Button variant="outline" className="text-white border-white hover:bg-white/10" asChild>
                  <a href="/feedback">Submit Feedback</a>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

