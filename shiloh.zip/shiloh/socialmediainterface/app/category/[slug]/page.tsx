import { notFound } from "next/navigation"
import Image from "next/image"
import Link from "next/link"
import { Heart, ShoppingBag, SlidersHorizontal } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"

// Mock data for demonstration
const categories = {
  men: {
    title: "Men's Collection",
    description: "Discover our premium collection for men",
    products: [
      {
        id: 1,
        name: "Classic Oxford Shirt",
        price: 120000,
        image: "/placeholder.svg?height=400&width=300",
        category: "men",
        subcategory: "shirts",
        isNew: true,
      },
      {
        id: 4,
        name: "Slim Fit Jeans",
        price: 140000,
        image: "/placeholder.svg?height=400&width=300",
        category: "men",
        subcategory: "pants",
      },
      {
        id: 7,
        name: "Casual Blazer",
        price: 260000,
        image: "/placeholder.svg?height=400&width=300",
        category: "men",
        subcategory: "jackets",
      },
      {
        id: 10,
        name: "Cotton T-Shirt",
        price: 60000,
        image: "/placeholder.svg?height=400&width=300",
        category: "men",
        subcategory: "shirts",
      },
      {
        id: 13,
        name: "Wool Sweater",
        price: 180000,
        image: "/placeholder.svg?height=400&width=300",
        category: "men",
        subcategory: "sweaters",
      },
      {
        id: 16,
        name: "Chino Pants",
        price: 120000,
        image: "/placeholder.svg?height=400&width=300",
        category: "men",
        subcategory: "pants",
      },
    ],
    filters: {
      subcategories: ["shirts", "pants", "jackets", "sweaters"],
      sizes: ["XS", "S", "M", "L", "XL", "XXL"],
      colors: ["Black", "White", "Blue", "Gray", "Green"],
    },
  },
  women: {
    title: "Women's Collection",
    description: "Explore our stylish collection for women",
    products: [
      {
        id: 2,
        name: "Elegant Summer Dress",
        price: 160000,
        originalPrice: 200000,
        image: "/placeholder.svg?height=400&width=300",
        category: "women",
        subcategory: "dresses",
        isSale: true,
      },
      {
        id: 5,
        name: "Silk Blouse",
        price: 140000,
        image: "/placeholder.svg?height=400&width=300",
        category: "women",
        subcategory: "tops",
      },
      {
        id: 8,
        name: "High-Waisted Jeans",
        price: 160000,
        image: "/placeholder.svg?height=400&width=300",
        category: "women",
        subcategory: "pants",
      },
      {
        id: 11,
        name: "Knit Cardigan",
        price: 140000,
        image: "/placeholder.svg?height=400&width=300",
        category: "women",
        subcategory: "sweaters",
      },
      {
        id: 14,
        name: "Pleated Skirt",
        price: 120000,
        image: "/placeholder.svg?height=400&width=300",
        category: "women",
        subcategory: "skirts",
      },
      {
        id: 17,
        name: "Leather Jacket",
        price: 400000,
        image: "/placeholder.svg?height=400&width=300",
        category: "women",
        subcategory: "jackets",
      },
    ],
    filters: {
      subcategories: ["dresses", "tops", "pants", "skirts", "sweaters", "jackets"],
      sizes: ["XS", "S", "M", "L", "XL"],
      colors: ["Black", "White", "Red", "Blue", "Pink", "Green"],
    },
  },
  kids: {
    title: "Kids' Collection",
    description: "Fun and comfortable styles for children of all ages",
    products: [
      {
        id: 19,
        name: "Cartoon Print T-Shirt",
        price: 40000,
        image: "/placeholder.svg?height=400&width=300",
        category: "kids",
        subcategory: "tops",
        isNew: true,
      },
      {
        id: 20,
        name: "Elastic Waist Jeans",
        price: 60000,
        image: "/placeholder.svg?height=400&width=300",
        category: "kids",
        subcategory: "pants",
      },
      {
        id: 21,
        name: "Hooded Sweatshirt",
        price: 70000,
        image: "/placeholder.svg?height=400&width=300",
        category: "kids",
        subcategory: "outerwear",
      },
      {
        id: 22,
        name: "Colorful Socks Set",
        price: 25000,
        image: "/placeholder.svg?height=400&width=300",
        category: "kids",
        subcategory: "accessories",
      },
      {
        id: 23,
        name: "School Uniform Shirt",
        price: 45000,
        image: "/placeholder.svg?height=400&width=300",
        category: "kids",
        subcategory: "uniforms",
      },
      {
        id: 24,
        name: "Summer Shorts",
        price: 35000,
        image: "/placeholder.svg?height=400&width=300",
        category: "kids",
        subcategory: "shorts",
      },
    ],
    filters: {
      subcategories: ["tops", "pants", "outerwear", "accessories", "uniforms", "shorts"],
      sizes: ["2T", "3T", "4T", "5", "6", "7", "8", "10", "12", "14"],
      colors: ["Blue", "Pink", "Green", "Yellow", "Red", "Purple"],
    },
  },
  footwear: {
    title: "Footwear Collection",
    description: "Step out in style with our premium footwear",
    products: [
      {
        id: 3,
        name: "Premium Leather Sneakers",
        price: 260000,
        image: "/placeholder.svg?height=400&width=300",
        category: "footwear",
        subcategory: "sneakers",
        isNew: true,
      },
      {
        id: 6,
        name: "Classic Leather Boots",
        price: 320000,
        image: "/placeholder.svg?height=400&width=300",
        category: "footwear",
        subcategory: "boots",
      },
      {
        id: 9,
        name: "Casual Loafers",
        price: 180000,
        image: "/placeholder.svg?height=400&width=300",
        category: "footwear",
        subcategory: "loafers",
      },
      {
        id: 12,
        name: "Running Shoes",
        price: 240000,
        image: "/placeholder.svg?height=400&width=300",
        category: "footwear",
        subcategory: "athletic",
      },
      {
        id: 15,
        name: "Dress Shoes",
        price: 300000,
        image: "/placeholder.svg?height=400&width=300",
        category: "footwear",
        subcategory: "formal",
      },
      {
        id: 18,
        name: "Summer Sandals",
        price: 100000,
        image: "/placeholder.svg?height=400&width=300",
        category: "footwear",
        subcategory: "sandals",
      },
    ],
    filters: {
      subcategories: ["sneakers", "boots", "loafers", "athletic", "formal", "sandals"],
      sizes: ["6", "7", "8", "9", "10", "11", "12"],
      colors: ["Black", "White", "Brown", "Blue", "Red"],
    },
  },
}

export default function CategoryPage({ params }: { params: { slug: string } }) {
  const { slug } = params

  if (!categories[slug as keyof typeof categories]) {
    notFound()
  }

  const category = categories[slug as keyof typeof categories]

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold">{category.title}</h1>
        <p className="text-black">{category.description}</p>
      </div>

      <div className="flex flex-col lg:flex-row gap-8">
        {/* Filters Sidebar */}
        <div className="lg:w-1/4">
          <div className="sticky top-20 bg-white p-4 border rounded-lg">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold">Filters</h2>
              <Button variant="ghost" size="sm" className="text-xs">
                <SlidersHorizontal className="h-4 w-4 mr-1" /> Filter
              </Button>
            </div>

            <div className="space-y-6">
              <div>
                <h3 className="font-medium mb-2">Category</h3>
                <div className="space-y-2">
                  {category.filters.subcategories.map((subcategory) => (
                    <div key={subcategory} className="flex items-center space-x-2">
                      <Checkbox id={`category-${subcategory}`} />
                      <Label htmlFor={`category-${subcategory}`} className="capitalize">
                        {subcategory}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>

              <Separator />

              <div>
                <h3 className="font-medium mb-2">Size</h3>
                <div className="space-y-2">
                  {category.filters.sizes.map((size) => (
                    <div key={size} className="flex items-center space-x-2">
                      <Checkbox id={`size-${size}`} />
                      <Label htmlFor={`size-${size}`}>{size}</Label>
                    </div>
                  ))}
                </div>
              </div>

              <Separator />

              <div>
                <h3 className="font-medium mb-2">Color</h3>
                <div className="space-y-2">
                  {category.filters.colors.map((color) => (
                    <div key={color} className="flex items-center space-x-2">
                      <Checkbox id={`color-${color}`} />
                      <Label htmlFor={`color-${color}`}>{color}</Label>
                    </div>
                  ))}
                </div>
              </div>

              <Separator />

              <div>
                <h3 className="font-medium mb-2">Price Range</h3>
                <div className="grid grid-cols-2 gap-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox id="price-under-50000" />
                    <Label htmlFor="price-under-50000">Under TSh 50,000</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="price-50000-100000" />
                    <Label htmlFor="price-50000-100000">TSh 50,000 - 100,000</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="price-100000-200000" />
                    <Label htmlFor="price-100000-200000">TSh 100,000 - 200,000</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="price-over-200000" />
                    <Label htmlFor="price-over-200000">Over TSh 200,000</Label>
                  </div>
                </div>
              </div>

              <Button className="w-full bg-shiloh-blue text-white hover:bg-shiloh-blue/90">Apply Filters</Button>
            </div>
          </div>
        </div>

        {/* Products Grid */}
        <div className="lg:w-3/4">
          <div className="flex justify-between items-center mb-6">
            <p className="text-black">Showing {category.products.length} products</p>
            <div className="flex items-center gap-2">
              <span className="text-sm">Sort by:</span>
              <Select defaultValue="featured">
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="featured">Featured</SelectItem>
                  <SelectItem value="newest">Newest</SelectItem>
                  <SelectItem value="price-low">Price: Low to High</SelectItem>
                  <SelectItem value="price-high">Price: High to Low</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {category.products.map((product) => (
              <div key={product.id} className="group relative">
                <div className="aspect-h-1 aspect-w-1 w-full overflow-hidden rounded-md bg-white group-hover:opacity-75">
                  <Image
                    src={product.image || "/placeholder.svg"}
                    alt={product.name}
                    width={300}
                    height={400}
                    className="h-full w-full object-cover object-center"
                  />
                  {product.isNew && <Badge className="absolute top-2 left-2 bg-black text-white">New</Badge>}
                  {product.isSale && <Badge className="absolute top-2 left-2 bg-red-600 text-white">Sale</Badge>}
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <div className="flex gap-2">
                      <Button size="icon" className="rounded-full bg-white text-black hover:bg-white/90">
                        <ShoppingBag className="h-5 w-5" />
                      </Button>
                      <Button size="icon" className="rounded-full bg-white text-black hover:bg-white/90">
                        <Heart className="h-5 w-5" />
                      </Button>
                    </div>
                  </div>
                </div>
                <div className="mt-4 flex justify-between">
                  <div>
                    <h3 className="text-sm font-medium text-black">
                      <Link href={`/product/${product.id}`}>
                        <span aria-hidden="true" className="absolute inset-0" />
                        {product.name}
                      </Link>
                    </h3>
                    <p className="mt-1 text-sm text-black capitalize">{product.subcategory}</p>
                  </div>
                  <div className="text-sm font-medium text-black">
                    {product.originalPrice ? (
                      <div className="flex flex-col items-end">
                        <span className="text-shiloh-blue">TSh {product.price.toLocaleString()}</span>
                        <span className="text-black line-through text-xs">
                          TSh {product.originalPrice.toLocaleString()}
                        </span>
                      </div>
                    ) : (
                      <span>TSh {product.price.toLocaleString()}</span>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

